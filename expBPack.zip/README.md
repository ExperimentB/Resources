# Experiment B Resource Pack (Private)
To release the public RP, create `expBPack.zip` file and upload it to the [Public Repo](https://github.com/ExperimentB/Resources).