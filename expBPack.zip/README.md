# Experiment B Resource Pack (Private)

## How to release the public RP
1. Create `expBPack.zip` file and upload it to the [Public Repo](https://github.com/ExperimentB/Resources).
